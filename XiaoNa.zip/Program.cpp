#include "Program.h"


//Program::Program()
//{
//	stack.push_back(Value());		// ��ֵ 0
//	stack.push_back(Value(true));		// ��ֵ1
//	stack.push_back(Value(false));		// ��ֵ2
//}


Program::~Program()
{
}
