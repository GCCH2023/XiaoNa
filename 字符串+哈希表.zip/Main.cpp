#include <stdio.h>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <hash_map>
using namespace std;
#include "String.h"

int main()
{
	// ����ַ���
	String *a = String::New("hello");
	String *b = String::New("hello");
	printf(" a(%s) == b(%s)  :  %s\n", 
		a->GetCStr(), b->GetCStr(), a == b ? "true" : "false");
	a = *b + *a;		// ����String����
	printf(" a(%s) == b(%s)  :  %s\n", a->GetCStr(), b->GetCStr(), a == b ? "true" : "false");
	a = *a + 100.9;  // ����double
	printf("%s\n", a->GetCStr());
	a = *a + " C++";  // ���� const char *
	printf("%s\n", a->GetCStr());
	a = *a + string(" yes");  // ���� std::string
	printf("%s\n", a->GetCStr());
	a = *a + 'B';  // ���� char
	printf("%s\n", a->GetCStr());
	String::Clear();
	system("pause");
	return 0;
}