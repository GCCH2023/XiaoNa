#include "ASTree.h"


ASTree::ASTree()
{
}


ASTree::~ASTree()
{
}
