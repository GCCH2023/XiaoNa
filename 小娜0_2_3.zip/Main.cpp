﻿//#include <stdio.h>
//#include <stdlib.h>
//#include <string>
//#include <hash_map>
//using namespace std;
//
//// 变量的值
//struct Value
//{
//	// 值的类别
//	enum{
//		VNULL = 0,		// 空值
//		VNUM,		//数值
//		VSTR,		//字符串
//	}type;		// type默认是空值
//	int ivalue = 0;
//	string svalue = "";
//	Value() :type(VNULL){}		// 默认null
//	Value(int iv) :ivalue(iv), type(VNUM){}		// 设置数值
//	Value(string str) :svalue(str), type(VSTR){}	//设置字符串
//};
//
//////////////////////////////////////全局变量////////////////////////////////////////////
//char c = ' ';			// 当前要识别的字符
//hash_map<string, Value> vars;		// 按名保存变量值的哈希表
/////////////////////////////////////////////////////////////////////////////////////////////////
//
//// 判断指定字符c是否是十进制字符
//inline bool isdigit(char c)
//{
//	return c >= '0' && c <= '9';
//}
//
//// 将十进制字符转化为十进制数值
//// c必须是十进制字符
//inline int digitvalue(char c)
//{
//	return c - '0';
//}
//
//// 判断指定字符c是否是八进制字符
//inline bool isoct(char c)
//{
//	return c >= '0' && c <= '7';
//}
//
//// 将八进制字符转化为十进制数值
//// c必须是八进制字符
//inline int octvalue(char c)
//{
//	return c - '0';
//}
//
//// 判断指定字符c是否是十六进制字符
//inline bool ishex(char c)
//{
//	char lower = c | 32;		// 将字母转为小写
//	return isdigit(c) || (lower >= 'a' && lower <= 'f');
//}
//
//// 将十六进制字符转化为十进制数值
//// c必须是十六进制字符
//inline int hexvalue(char c)
//{
//	return isdigit(c) ? c - '0' : (c | 32) - 'a';
//}
//
//// 判断指定字符串c是否是字母
//// 这里把英文字母，下划线和扩展字符（小于-1的字符）
//// 都归为字母
//inline bool isletter(char c)
//{
//	char lower = c | 32;		// 将英文字母转为小写
//	return c < -1 ||
//		c >= 'a' && c <= 'z' ||
//		c == '_';
//}
//
//// 报错
//// msg：错误信息
//void error(char expected, char actual)
//{
//	printf("错误：期待的是“%c”，实际上是“%c”!\n", expected, actual);
//	system("pause");
//	exit(-1);
//}
//
//// 获取下一个要识别的字符，将其保存到全局变量c中
//// 返回新获取的字符
//char getch()
//{
//	char ch = ' ';
//	// 是空格就跳过
//	while (ch == ' ' || ch == '\n' || ch == '\t')
//		scanf("%c", &ch);
//	// 肯定不是空格了
//	c = ch;
//	return ch;
//}
//
//
//// 识别正整数，返回正整数的值
//int numerical()
//{
//	// 接下来是数字，0个以上的数字字符序列
//	if (isdigit(c) == false){
//		// 至少要有一个数字字符
//		error('d', c);	// 'd' 代表数字字符（digit）
//	}
//	int value = digitvalue(c);			// 记录数字的值
//	// 后面可以跟任意多个数字字符
//	getch();
//	while (isdigit(c)){
//		// 增加value的值并读入下一个字符
//		value = value * 10 + digitvalue(c);
//		getch();
//	}
//	return value;
//}
//
//// 对字符串进行转义处理，返回转义后的字符串
//// str：要转义的字符串
//string escape(string str)
//{
//	string s;
//	char *p = &str[0];		//指向str中字符串数据的指针
//	while (*p != '\0'){
//#pragma region 具体实现
//		if (*p == '\\'){		// 转义字符开始？
//			// 忽略'\\'，下一个字符
//			p++;
//			switch (*p)
//			{
//			case '\0':	throw "'\\'后面缺少转义字符"; break;		//还没转义就结束了
//			case 'a': s.push_back('\a'); p++; break;
//			case 'b': s.push_back('\b'); p++; break;
//			case 'f': s.push_back('\f'); p++; break;
//			case 'n': s.push_back('\n'); p++; break;
//			case 'r': s.push_back('\r'); p++; break;
//			case 't': s.push_back('\t'); p++; break;
//			case 'v': s.push_back('\v'); p++; break;
//			case 'x':case 'X':		// 十六进制字符
//			{
//						 p++;		//跳过x
//						 int value = 0;
//						 for (int i = 0; i < 2; i++){		// 最多两位
//							 if (ishex(*p)){		// 是十六进制字符就增加value的值
//								 value = value * 16 + hexvalue(*p);
//								 p++;
//							 }
//							 else break;		// 不是则结束循环
//						 }
//						 s.push_back(value);
//						 break;
//			}
//			default:		// 八进制字符或普通字符
//			{
//								if (isoct(*p)){
//									int value = *p - '0'; p++;
//									for (int i = 0; i < 2; i++){		// 最多三位，但已经识别了一位
//										if (isoct(*p)){
//											value = value * 8 + octvalue(*p); p++;
//										}
//										else break;			// 不是十六进制字符，结束循环
//									}
//									// 判断是否超过255
//									if (value > 255){
//										char buff[20];
//										sprintf_s(buff, "%d对于字符来说太大了", value);
//										throw buff;
//									}
//									// 加入字符串中
//									s.push_back((char)value);
//									continue;
//								}
//								s.push_back(*p);		// 普通字符不转义
//								p++;
//			}
//			}
//		}
//		else{
//			s.push_back(*p);		// 普通字符直接放进去
//			p++;
//		}
//#pragma endregion 具体实现
//	}
//	return s;
//}
//
//// 对注释的处理
//// “ // ”开头，直到换行
//// 返回是否是注释
//bool comment()
//{
//	if (c == '/' && getch() == '/'){
//		// 直到换行
//		while (c != '\n' && c != EOF)
//			scanf("%c", &c);		//这里不能用getch，因为它会跳过'\n'
//		// 跳过'\n'，继续
//		getch();
//		return true;
//	}
//	return false;
//}
//
//// 字符串的识别
//// 双引号（单引号）开始，中间的若干字符属于字符串，
//// 最后以双引号（单引号结束）
//// 返回识别出的字符串
//string stringliteral()
//{
//	char quot = ' ';		// 保存是单引号还是双引号
//	if (c == '"' || c == '\'') quot = c;
//	else error('"', c);
//	scanf("%c", &c);		//字符串里的空格不能忽略，跳过开始的双引号
//	string str;		//创建一个空字符串
//	while (c != quot){
//		if (c == EOF) error(quot, '#');		// 暂时先用'#'表示文件结束
//		str.push_back(c);
//		scanf("%c", &c);		//字符串里的空格不能忽略
//	}
//	scanf("%c", &c);		//字符串里的空格不能忽略，跳过结尾的双引号
//	return escape(str);		//对str进行转义处理
//}
//
//// 标识符的识别，字母开头，后跟若干字母或数字
//// 返回标识符名
//string identifier()
//{
//	string id;
//	if (isletter(c) == false)
//		error('_', c);		// 先用下划线代表字母报错吧
//	id.push_back(c);
//	// 读下一个字符，且下一个字符是字母或数字
//	scanf("%c", &c);
//	while (isletter(c) || isdigit(c)){
//		id.push_back(c);
//		scanf("%c", &c);
//	}
//	return id;
//}
//
//
//// 函数参数
//// 支持任意多个正整数和字符串，用','间隔
//void argument()
//{
//	// 可以有任意多个正整数
//	if (c == ')'){
//		getch();
//		return;
//	}
//	do{
//		if (isdigit(c))		// 正整数
//			printf("%d", numerical());
//		else if(c == '\'' || c == '"')			// 字符串
//			printf("%s", stringliteral().c_str());
//		else if (isletter(c)){		// 变量
//			string id = identifier();
//			// 如果找到就输出变量的值，否则输出null
//			if (vars.find(id) == vars.end())	// 找不到
//				printf("null");
//			else{
//				Value v = vars[id];
//				if (v.type == Value::VNUM)
//					printf("%d", v.ivalue);
//				else if (v.type == Value::VSTR)
//					printf("%s", v.svalue.c_str());
//				else
//					printf("null");
//			}
//		}
//		else
//			error('a', c);		// a代表参数
//	} while (c == ',' && getch());	// 如果是逗号，就读入下一个字符
//}
//
//// 函数识别并调用，目前只支持print
//void function()
//{
//	// "print" 字符串，用于比较
//	const char word[] = "print";
//	int i = 0;		// 指向“print”中当前要识别的字符
//	while (word[i] != '\0'){
//		if (c != word[i]) error(word[i], c);
//		getch();		i++;
//	}
//	// 接下来是左括号
//	if (c != '(') error('(', c);
//	getch();
//	// 参数
//	argument();
//	// 最后是右括号
//	if (c != ')') error(')', c);
//	// 继续读取一个字符
//	getch();
//}
//
//// 赋值语句
//// id = string | number
//void assign()
//{
//	string id = identifier();
//	if (c != '=') error('=', c);
//	getch();
//	if (isdigit(c)){	// 正整数
//		int value = numerical();
//		vars.insert({ id, Value(value) });	// 添加变量的 值到哈希表中
//	}
//	else if(c == '"' || c == '\''){		// 字符串
//		string str = stringliteral();
//		vars.insert({ id, Value(str) });	// 添加变量的 值到哈希表中
//	}
//	else
//		error('v', c);		// v代表值（value）
//}
//
//// 对源代码进行识别，并运行
//void parse()
//{
//	while (true){
//		switch (c){
//		case EOF:system("pause"); return;	// 退出编译
//		case '/':		//可能是注释，也可能不是
//			if (comment() == false)
//				error('/', c);		// 不是注释的话报错
//			break;
//		case 'p':		// 识别 “print”
//			function();
//			break;
//		default:	// 其他的字符都是非法字符
//			if (isletter(c))		// 字母开头
//				assign();
//			else
//				error('?', c);
//		}
//	}
//}

#include <iostream>
#include "FileStream.h"
#include "Parser.h"

int main()
{
	std::cout << sizeof(Value) << std::endl;
	// 从文件读取源代码并分析
	FileStream fs("test.txt");
	Parser parser(fs);
	Program *p = parser.Parse();
	p->Execute();
	delete p;
	system("pause");
	return 0;
}