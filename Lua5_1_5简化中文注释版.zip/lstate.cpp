/*
** $Id: lstate.c,v 2.36.1.2 2008/01/03 15:20:39 roberto Exp $
** Global State
** See Copyright Notice in lua.h
*/


#include <stddef.h>

#define lstate_c
#define LUA_CORE

#include "lua.h"

#include "ldebug.h"
#include "ldo.h"
#include "lfunc.h"
#include "lgc.h"
#include "llex.h"
#include "lmem.h"
#include "lstate.h"
#include "lstring.h"
#include "ltable.h"
#include "ltm.h"


#define tostate(l)   (cast(lua_State *, l))


// ���̰߳���һ���߳�״̬��һ��ȫ��״̬
struct LG {
	lua_State l;
	global_State g;
};

global_State *gstate = nullptr;

static void stack_init(lua_State *L1, lua_State *L) {
	// ��ʼ��������Ϣ����
	L1->base_ci = luaM_newvector(L, BASIC_CI_SIZE, CallInfo);
	L1->ci = L1->base_ci;
	L1->size_ci = BASIC_CI_SIZE;
	L1->end_ci = L1->base_ci + L1->size_ci - 1;
	// ��ʼ��ջ����
	L1->stack = luaM_newvector(L, BASIC_STACK_SIZE + EXTRA_STACK, TValue);
	L1->stacksize = BASIC_STACK_SIZE + EXTRA_STACK;
	L1->top = L1->stack;
	L1->stack_last = L1->stack + (L1->stacksize - EXTRA_STACK) - 1;
	// ��ʼ����һ������������Ϣ
	L1->ci->func = L1->top;
	setnilvalue(L1->top++);  // ����������õĺ������ /* `function' entry for this `ci' */
	L1->base = L1->ci->base = L1->top;
	L1->ci->top = L1->top + LUA_MINSTACK;
}


static void freestack(lua_State *L, lua_State *L1) {
	luaM_freearray(L, L1->base_ci, L1->size_ci, CallInfo);
	luaM_freearray(L, L1->stack, L1->stacksize, TValue);
}


/*
** open parts that may cause memory-allocation errors
*/
// �򿪿��ܵ����ڴ�������Ĳ���
static void f_luaopen(lua_State *L, void *ud) {
	stack_init(L, L);  // ��ʼ��ջ
	sethvalue(L, gt(L), Table::New(L, 0, 2));  // ȫ�ֱ�����
	sethvalue(L, registry(L), Table::New(L, 0, 2));  // ע���
	luaS_resize(L, MINSTRTABSIZE);  // ��ʼ���ַ�����
	luaT_init(L);		// ��ʼ��Ԫ����
	LexState::init(L);		// ��ʼ������������
	luaS_newliteral(L, MEMERRMSG)->fix();		// ���ڴ治�㡱
	GS->GCthreshold = 4 * GS->totalbytes;	// ����������ֵ
}


static void preinit_state(lua_State *L) {
	L->next = nullptr;
	L->tt = LUA_TTHREAD;
	L->marked = luaC_white(GS);
	set2bits(L->marked, FIXEDBIT, SFIXEDBIT);
	L->stack = nullptr;
	L->stacksize = 0;
	L->errorJmp = nullptr;
	L->hook = nullptr;
	L->hookmask = 0;
	L->basehookcount = 0;
	L->allowhook = 1;
	resethookcount(L);
	L->openupval = nullptr;
	L->size_ci = 0;
	L->nCcalls = L->baseCcalls = 0;
	L->status = 0;
	L->base_ci = L->ci = nullptr;
	L->savedpc = nullptr;
	L->errfunc = 0;
	setnilvalue(gt(L));
	setnilvalue(registry(L));
}


static void close_state(lua_State *L) {
	luaF_close(L, L->stack);  /* close all upvalues for this thread */
	luaC_freeall(L);  /* collect all objects */
	luaM_freearray(L, GS->strt.hash, GS->strt.size, TString *);
	GS->buff.free(L);
	freestack(L, L);
	(*GS->frealloc)(GS->ud, L, sizeof(LG), 0);
	gstate = nullptr;
}


lua_State *luaE_newthread(lua_State *L) {
	lua_State *L1 = tostate(luaM_malloc(L, sizeof(lua_State)));
	luaC_link(L, (L1), LUA_TTHREAD);
	preinit_state(L1);
	stack_init(L1, L);  /* init stack */
	setobj(L, gt(L1), gt(L));  /* share table of globals */
	L1->hookmask = L->hookmask;
	L1->basehookcount = L->basehookcount;
	L1->hook = L->hook;
	resethookcount(L1);
	return L1;
}


void luaE_freethread(lua_State *L, lua_State *L1) {
	luaF_close(L1, L1->stack);  /* close all upvalues for this thread */
	freestack(L, L1);
	luaM_freemem(L, L1, sizeof(lua_State));
}

static void initgstate(lua_State *L, lua_Alloc f, void *ud)
{
	GS->currentwhite = bit2mask(WHITE0BIT, FIXEDBIT);
	GS->frealloc = f;
	GS->ud = ud;
	GS->mainthread = L;
	GS->uvhead.u.l.prev = &GS->uvhead;
	GS->uvhead.u.l.next = &GS->uvhead;
	GS->GCthreshold = 0;  /* mark it as unfinished state */
	GS->strt.size = 0;
	GS->strt.nuse = 0;
	GS->strt.hash = nullptr;
	GS->buff = Mbuffer();
	GS->panic = nullptr;
	GS->gcstate = GCSpause;
	GS->rootgc = (L);
	GS->sweepstrgc = 0;
	GS->sweepgc = &GS->rootgc;
	GS->gray = nullptr;
	GS->grayagain = nullptr;
	GS->weak = nullptr;
	GS->tmudata = nullptr;
	GS->totalbytes = sizeof(LG);
	GS->gcpause = LUAI_GCPAUSE;
	GS->gcstepmul = LUAI_GCMUL;
	GS->gcdept = 0;
	for (int i = 0; i < NUM_TAGS; i++) GS->mt[i] = nullptr;
}

lua_State *lua_State::New(lua_Alloc f, void *ud) {
	// Ϊlua_State��global_State�����ڴ�
	void *l = (*f)(ud, nullptr, 0, sizeof(LG));
	if (l == nullptr) return nullptr;
	lua_State *L = tostate(l);
	GS = &((LG *)L)->g;
	// ��ʼ��
	preinit_state(L);
	initgstate(L, f, ud);
	// ���Գ�ʼ��ջ�����ʧ�ܾͷ��ؿ�
	if (luaD_rawrunprotected(L, f_luaopen, nullptr) != 0) {
		/* memory allocation error: free partial state */
		close_state(L);
		L = nullptr;
	}
	return L;
}


static void callallgcTM(lua_State *L, void *ud) {
	luaC_callGCTM(L);  /* call GC metamethods for all udata */
}


void lua_close(lua_State *L) {
	L = GS->mainthread;  /* only the main thread can be closed */

	luaF_close(L, L->stack);  /* close all upvalues for this thread */
	luaC_separateudata(L, 1);  /* separate udata that have GC metamethods */
	L->errfunc = 0;  /* no error function during GC metamethods */
	do {  /* repeat until no more errors */
		L->ci = L->base_ci;
		L->base = L->top = L->ci->base;
		L->nCcalls = L->baseCcalls = 0;
	} while (luaD_rawrunprotected(L, callallgcTM, nullptr) != 0);
	close_state(L);
}

