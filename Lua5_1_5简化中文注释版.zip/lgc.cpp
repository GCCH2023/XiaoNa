/*
** $Id: lgc.c,v 2.38.1.2 2011/03/18 18:05:38 roberto Exp $
** Garbage Collector
** See Copyright Notice in lua.h
*/

#include <string.h>

#define lgc_c
#define LUA_CORE

#include "lua.h"

#include "ldebug.h"
#include "ldo.h"
#include "lfunc.h"
#include "lgc.h"
#include "lmem.h"
#include "lobject.h"
#include "lstate.h"
#include "lstring.h"
#include "ltable.h"
#include "ltm.h"


#define GCSTEPSIZE	1024u
#define GCSWEEPMAX	40
#define GCSWEEPCOST	10
#define GCFINALIZECOST	100


#define maskmarks	cast_byte(~(bitmask(BLACKBIT)|WHITEBITS))

#define makewhite(g,x)	\
   ((x)->marked = cast_byte(((x)->marked & maskmarks) | luaC_white(g)))

#define white2gray(x)	reset2bits((x)->marked, WHITE0BIT, WHITE1BIT)
#define black2gray(x)	resetbit((x)->marked, BLACKBIT)

#define stringmark(s)	reset2bits((s)->marked, WHITE0BIT, WHITE1BIT)


#define isfinalized(u)		testbit((u)->marked, FINALIZEDBIT)
#define markfinalized(u)	l_setbit((u)->marked, FINALIZEDBIT)


#define KEYWEAK         bitmask(KEYWEAKBIT)
#define VALUEWEAK       bitmask(VALUEWEAKBIT)



#define markvalue(g,o) { \
  if (iscollectable(o) && iswhite(gcvalue(o))) reallymarkobject(g,gcvalue(o)); }

#define markobject(g,t) { if (iswhite((t))) \
		reallymarkobject(g, (t)); }


#define setthreshold(g)  (g->GCthreshold = (g->estimate/100) * g->gcpause)


static void removeentry (Node *n) {
  if (iscollectable(n->getkey()))
    setttype(n->getkey(), LUA_TDEADKEY);  /* dead key; remove it */
}


static void reallymarkobject (global_State *g, GCObject *o) {
  white2gray(o);
  switch (o->tt) {
    case LUA_TSTRING: {
      return;
    }
    case LUA_TUSERDATA: {
      Table *mt = gco2ud(o)->metatable;
      gray2black(o);  /* udata are never gray */
      if (mt) markobject(g, mt);
      markobject(g, gco2ud(o)->env);
      return;
    }
    case LUA_TUPVAL: {
      UpVal *uv = gco2uv(o);
      markvalue(g, uv->v);
      if (uv->v == &uv->u.value)  /* closed? */
        gray2black(o);  /* open upvalues are never black */
      return;
    }
    case LUA_TFUNCTION: {
      gco2cl(o)->gclist = g->gray;
      g->gray = o;
      break;
    }
    case LUA_TTABLE: {
      gco2h(o)->gclist = g->gray;
      g->gray = o;
      break;
    }
    case LUA_TTHREAD: {
      gco2th(o)->gclist = g->gray;
      g->gray = o;
      break;
    }
    case LUA_TPROTO: {
      gco2p(o)->gclist = g->gray;
      g->gray = o;
      break;
    }
    default: ;
  }
}


static void marktmu (global_State *g) {
  GCObject *u = g->tmudata;
  if (u) {
    do {
      u = u->next;
      makewhite(g, u);  /* may be marked, if left from previous GC */
      reallymarkobject(g, u);
    } while (u != g->tmudata);
  }
}


/* move `dead' udata that need finalization to list `tmudata' */
size_t luaC_separateudata (lua_State *L, int all) {
  size_t deadmem = 0;
  GCObject **p = &GS->mainthread->next;
  GCObject *curr;
  while ((curr = *p) != nullptr) {
    if (!(iswhite(curr) || all) || isfinalized(gco2ud(curr)))
      p = &curr->next;  /* don't bother with them */
    else if (fasttm(L, gco2ud(curr)->metatable, TM_GC) == nullptr) {
      markfinalized(gco2ud(curr));  /* don't need finalization */
      p = &curr->next;
    }
    else {  /* must call its gc method */
      deadmem += gco2ud(curr)->size();
      markfinalized(gco2ud(curr));
      *p = curr->next;
      /* link `curr' at the end of `tmudata' list */
      if (GS->tmudata == nullptr)  /* list is empty? */
        GS->tmudata = curr->next = curr;  /* creates a circular list */
      else {
        curr->next = GS->tmudata->next;
        GS->tmudata->next = curr;
        GS->tmudata = curr;
      }
    }
  }
  return deadmem;
}


static int traversetable (global_State *g, Table *h) {
  int i;
  int weakkey = 0;
  int weakvalue = 0;
  const TValue *mode;
  if (h->metatable)
    markobject(g, h->metatable);
  mode = gfasttm(g, h->metatable, TM_MODE);
  if (mode && ttisstring(mode)) {  /* is there a weak mode? */
    weakkey = (strchr(svalue(mode), 'k') != nullptr);
    weakvalue = (strchr(svalue(mode), 'v') != nullptr);
    if (weakkey || weakvalue) {  /* is really weak? */
      h->marked &= ~(KEYWEAK | VALUEWEAK);  /* clear bits */
      h->marked |= cast_byte((weakkey << KEYWEAKBIT) |
                             (weakvalue << VALUEWEAKBIT));
      h->gclist = g->weak;  /* must be cleared after GC, ... */
      g->weak = (h);  /* ... so put in the appropriate list */
    }
  }
  if (weakkey && weakvalue) return 1;
  if (!weakvalue) {
    i = h->sizearray;
    while (i--)
      markvalue(g, &h->array[i]);
  }
  i = sizenode(h);
  while (i--) {
	  Node *n = h->getnode(i);
    if (ttisnil(n->getvalue()))
      removeentry(n);  /* remove empty entries */
    else {
      if (!weakkey) markvalue(g, n->getkey());
      if (!weakvalue) markvalue(g, n->getvalue());
    }
  }
  return weakkey || weakvalue;
}


/*
** All marks are conditional because a GC may happen while the
** prototype is still being created
*/
static void traverseproto (global_State *g, Proto *f) {
  int i;
  if (f->source) stringmark(f->source);
  for (i=0; i<f->sizek; i++)  /* mark literals */
    markvalue(g, &f->k[i]);
  for (i=0; i<f->sizeupvalues; i++) {  /* mark upvalue names */
    if (f->upvalues[i])
      stringmark(f->upvalues[i]);
  }
  for (i=0; i<f->sizep; i++) {  /* mark nested protos */
    if (f->p[i])
      markobject(g, f->p[i]);
  }
  for (i=0; i<f->sizelocvars; i++) {  /* mark local-variable names */
    if (f->locvars[i].varname)
      stringmark(f->locvars[i].varname);
  }
}



static void traverseclosure(global_State *g, Closure *cl) {
	markobject(g, cl->env);
	if (cl->isC) {
		int i;
		for (i = 0; i < cl->nupvalues; i++)  /* mark its upvalues */
			markvalue(g, &ccl(cl)->upvalue[i]);
	}
	else {
		int i;
		LClosure *lclosure = lcl(cl);
		markobject(g, lclosure->p);
		for (i = 0; i < lclosure->nupvalues; i++)  /* mark its upvalues */
			markobject(g, lclosure->upvals[i]);
	}
}


static void checkstacksizes (lua_State *L, StkId max) {
  int ci_used = cast_int(L->ci - L->base_ci);  /* number of `ci' in use */
  int s_used = cast_int(max - L->stack);  /* part of stack in use */
  if (L->size_ci > LUAI_MAXCALLS)  /* handling overflow? */
    return;  /* do not touch the stacks */
  if (4*ci_used < L->size_ci && 2*BASIC_CI_SIZE < L->size_ci)
    luaD_reallocCI(L, L->size_ci/2);  /* still big enough... */
  if (4*s_used < L->stacksize &&
      2*(BASIC_STACK_SIZE+EXTRA_STACK) < L->stacksize)
    luaD_reallocstack(L, L->stacksize/2);  /* still big enough... */
}


static void traversestack (global_State *g, lua_State *l) {
  StkId o, lim;
  CallInfo *ci;
  markvalue(g, gt(l));
  lim = l->top;
  for (ci = l->base_ci; ci <= l->ci; ci++) {
    if (lim < ci->top) lim = ci->top;
  }
  for (o = l->stack; o < l->top; o++)
    markvalue(g, o);
  for (; o <= lim; o++)
    setnilvalue(o);
  checkstacksizes(l, lim);
}


/*
** traverse one gray object, turning it to black.
** Returns `quantity' traversed.
*/
static l_mem propagatemark (global_State *g) {
  GCObject *o = g->gray;
  gray2black(o);
  switch (o->tt) {
    case LUA_TTABLE: {
      Table *h = gco2h(o);
      g->gray = h->gclist;
      if (traversetable(g, h))  /* table is weak? */
        black2gray(o);  /* keep it gray */
      return sizeof(Table) + sizeof(TValue) * h->sizearray +
                             sizeof(Node) * sizenode(h);
    }
    case LUA_TFUNCTION: {
      Closure *cl = gco2cl(o);
      g->gray = cl->gclist;
      traverseclosure(g, cl);
      return (cl->isC) ? sizeCclosure(cl->nupvalues) :
                           sizeLclosure(cl->nupvalues);
    }
    case LUA_TTHREAD: {
      lua_State *th = gco2th(o);
      g->gray = th->gclist;
      th->gclist = g->grayagain;
      g->grayagain = o;
      black2gray(o);
      traversestack(g, th);
      return sizeof(lua_State) + sizeof(TValue) * th->stacksize +
                                 sizeof(CallInfo) * th->size_ci;
    }
    case LUA_TPROTO: {
      Proto *p = gco2p(o);
      g->gray = p->gclist;
      traverseproto(g, p);
      return sizeof(Proto) + sizeof(Instruction) * p->sizecode +
                             sizeof(Proto *) * p->sizep +
                             sizeof(TValue) * p->sizek + 
                             sizeof(int) * p->sizelineinfo +
                             sizeof(LocVar) * p->sizelocvars +
                             sizeof(TString *) * p->sizeupvalues;
    }
    default: return 0;
  }
}


static size_t propagateall (global_State *g) {
  size_t m = 0;
  while (g->gray) m += propagatemark(g);
  return m;
}


/*
** The next function tells whether a key or value can be cleared from
** a weak table. Non-collectable objects are never removed from weak
** tables. Strings behave as `values', so are never removed too. for
** other objects: if really collected, cannot keep them; for userdata
** being finalized, keep them in keys, but not in values
*/
static int iscleared (const TValue *o, int iskey) {
  if (!iscollectable(o)) return 0;
  if (ttisstring(o)) {
    stringmark(tsvalue(o));  /* strings are `values', so are never weak */
    return 0;
  }
  return iswhite(gcvalue(o)) ||
    (ttisuserdata(o) && (!iskey && isfinalized(uvalue(o))));
}


/*
** clear collected entries from weaktables
*/
static void cleartable (GCObject *l) {
  while (l) {
    Table *h = gco2h(l);
    int i = h->sizearray;
    if (testbit(h->marked, VALUEWEAKBIT)) {
      while (i--) {
        TValue *o = &h->array[i];
        if (iscleared(o, 0))  /* value was collected? */
          setnilvalue(o);  /* remove value */
      }
    }
    i = sizenode(h);
    while (i--) {
		Node *n = h->getnode(i);
      if (!ttisnil(n->getvalue()) &&  /* non-empty entry? */
          (iscleared(n->getkey(), 1) || iscleared(n->getvalue(), 0))) {
        setnilvalue(n->getvalue());  /* remove value ... */
        removeentry(n);  /* remove entry from table */
      }
    }
    l = h->gclist;
  }
}


static void freeobj (lua_State *L, GCObject *o) {
  switch (o->tt) {
  case LUA_TPROTO: Proto::Del(L, gco2p(o)); break;
  case LUA_TFUNCTION: Closure::Del(L, gco2cl(o)); break;
    case LUA_TUPVAL: UpVal::Del(L, gco2uv(o)); break;
    case LUA_TTABLE: gco2h(o)->free(L); break;
    case LUA_TTHREAD: {
      luaE_freethread(L, gco2th(o));
      break;
    }
    case LUA_TSTRING: {
      GS->strt.nuse--;
      luaM_freemem(L, o, gco2ts(o)->size());
      break;
    }
    case LUA_TUSERDATA: {
      luaM_freemem(L, o, gco2ud(o)->size());
      break;
    }
    default: ;
  }
}



#define sweepwholelist(L,p)	sweeplist(L,p,MAX_LUMEM)


static GCObject **sweeplist (lua_State *L, GCObject **p, lu_mem count) {
  GCObject *curr;
  int deadmask = otherwhite(GS);
  while ((curr = *p) != nullptr && count-- > 0) {
    if (curr->tt == LUA_TTHREAD)  /* sweep open upvalues of each thread */
      sweepwholelist(L, &gco2th(curr)->openupval);
    if ((curr->marked ^ WHITEBITS) & deadmask) {  /* not dead? */
      makewhite(GS, curr);  /* make it white (for next cycle) */
      p = &curr->next;
    }
    else {  /* must erase `curr' */
      *p = curr->next;
      if (curr == GS->rootgc)  /* is the first element of the list? */
        GS->rootgc = curr->next;  /* adjust first */
      freeobj(L, curr);
    }
  }
  return p;
}


static void checkSizes (lua_State *L) {
  /* check size of string hash */
  if (GS->strt.nuse < cast(lu_int32, GS->strt.size/4) &&
      GS->strt.size > MINSTRTABSIZE*2)
    luaS_resize(L, GS->strt.size/2);  /* table is too big */
  /* check size of buffer */
  if (GS->buff.buffsize > LUA_MINBUFFER*2) {  /* buffer too big? */
    size_t newsize = GS->buff.buffsize / 2;
	GS->buff.resize(L, newsize);
  }
}


static void GCTM (lua_State *L) {
  GCObject *o = GS->tmudata->next;  /* get first element */
  Udata *udata = gco2ud(o);
  const TValue *tm;
  /* remove udata from `tmudata' */
  if (o == GS->tmudata)  /* last element? */
    GS->tmudata = nullptr;
  else
    GS->tmudata->next = udata->next;
  udata->next = GS->mainthread->next;  /* return it to `root' list */
  GS->mainthread->next = o;
  makewhite(GS, o);
  tm = fasttm(L, udata->metatable, TM_GC);
  if (tm != nullptr) {
    byte oldah = L->allowhook;
    lu_mem oldt = GS->GCthreshold;
    L->allowhook = 0;  /* stop debug hooks during GC tag method */
    GS->GCthreshold = 2*GS->totalbytes;  /* avoid GC steps */
    setobj(L, L->top, tm);
    setuvalue(L, L->top+1, udata);
    L->top += 2;
    luaD_call(L, L->top - 2, 0);
    L->allowhook = oldah;  /* restore hooks */
    GS->GCthreshold = oldt;  /* restore threshold */
  }
}


/*
** Call all GC tag methods
*/
void luaC_callGCTM (lua_State *L) {
  while (GS->tmudata)
    GCTM(L);
}


void luaC_freeall (lua_State *L) {
  GS->currentwhite = WHITEBITS | bitmask(SFIXEDBIT);  /* mask to collect all elements */
  sweepwholelist(L, &GS->rootgc);
  for (int i = 0; i < GS->strt.size; i++)  /* free all string lists */
    sweepwholelist(L, &GS->strt.hash[i]);
}


static void markmt (global_State *g) {
  int i;
  for (i=0; i<NUM_TAGS; i++)
    if (g->mt[i]) markobject(g, g->mt[i]);
}


/* mark root set */
static void markroot (lua_State *L) {
  GS->gray = nullptr;
  GS->grayagain = nullptr;
  GS->weak = nullptr;
  markobject(GS, GS->mainthread);
  /* make global table be traversed before main stack */
  markvalue(GS, gt(GS->mainthread));
  markvalue(GS, registry(L));
  markmt(GS);
  GS->gcstate = GCSpropagate;
}


static void remarkupvals (global_State *g) {
  UpVal *uv;
  for (uv = g->uvhead.u.l.next; uv != &g->uvhead; uv = uv->u.l.next) {
    if (isgray((uv)))
      markvalue(g, uv->v);
  }
}


static void atomic (lua_State *L) {
  size_t udsize;  /* total size of userdata to be finalized */
  /* remark occasional upvalues of (maybe) dead threads */
  remarkupvals(GS);
  /* traverse objects cautch by write barrier and by 'remarkupvals' */
  propagateall(GS);
  /* remark weak tables */
  GS->gray = GS->weak;
  GS->weak = nullptr;
  markobject(GS, L);  /* mark running thread */
  markmt(GS);  /* mark basic metatables (again) */
  propagateall(GS);
  /* remark gray again */
  GS->gray = GS->grayagain;
  GS->grayagain = nullptr;
  propagateall(GS);
  udsize = luaC_separateudata(L, 0);  /* separate userdata to be finalized */
  marktmu(GS);  /* mark `preserved' userdata */
  udsize += propagateall(GS);  /* remark, to propagate `preserveness' */
  cleartable(GS->weak);  /* remove collected objects from weak tables */
  /* flip current white */
  GS->currentwhite = cast_byte(otherwhite(GS));
  GS->sweepstrgc = 0;
  GS->sweepgc = &GS->rootgc;
  GS->gcstate = GCSsweepstring;
  GS->estimate = GS->totalbytes - udsize;  /* first estimate */
}


static l_mem singlestep (lua_State *L) {
  /*lua_checkmemory(L);*/
  switch (GS->gcstate) {
    case GCSpause: {
      markroot(L);  /* start a new collection */
      return 0;
    }
    case GCSpropagate: {
      if (GS->gray)
        return propagatemark(GS);
      else {  /* no more `gray' objects */
        atomic(L);  /* finish mark phase */
        return 0;
      }
    }
    case GCSsweepstring: {
      lu_mem old = GS->totalbytes;
      sweepwholelist(L, &GS->strt.hash[GS->sweepstrgc++]);
      if (GS->sweepstrgc >= GS->strt.size)  /* nothing more to sweep? */
        GS->gcstate = GCSsweep;  /* end sweep-string phase */
      GS->estimate -= old - GS->totalbytes;
      return GCSWEEPCOST;
    }
    case GCSsweep: {
      lu_mem old = GS->totalbytes;
      GS->sweepgc = sweeplist(L, GS->sweepgc, GCSWEEPMAX);
      if (*GS->sweepgc == nullptr) {  /* nothing more to sweep? */
        checkSizes(L);
        GS->gcstate = GCSfinalize;  /* end sweep phase */
      }
      GS->estimate -= old - GS->totalbytes;
      return GCSWEEPMAX*GCSWEEPCOST;
    }
    case GCSfinalize: {
      if (GS->tmudata) {
        GCTM(L);
        if (GS->estimate > GCFINALIZECOST)
          GS->estimate -= GCFINALIZECOST;
        return GCFINALIZECOST;
      }
      else {
        GS->gcstate = GCSpause;  /* end collection */
        GS->gcdept = 0;
        return 0;
      }
    }
    default: return 0;
  }
}


void luaC_step (lua_State *L) {
  l_mem lim = (GCSTEPSIZE/100) * GS->gcstepmul;
  if (lim == 0)
    lim = (MAX_LUMEM-1)/2;  /* no limit */
  GS->gcdept += GS->totalbytes - GS->GCthreshold;
  do {
    lim -= singlestep(L);
    if (GS->gcstate == GCSpause)
      break;
  } while (lim > 0);
  if (GS->gcstate != GCSpause) {
    if (GS->gcdept < GCSTEPSIZE)
      GS->GCthreshold = GS->totalbytes + GCSTEPSIZE;  /* - lim/GS->gcstepmul;*/
    else {
      GS->gcdept -= GCSTEPSIZE;
      GS->GCthreshold = GS->totalbytes;
    }
  }
  else {
    setthreshold(GS);
  }
}


void luaC_fullgc (lua_State *L) {
  if (GS->gcstate <= GCSpropagate) {
    /* reset sweep marks to sweep all elements (returning them to white) */
    GS->sweepstrgc = 0;
    GS->sweepgc = &GS->rootgc;
    /* reset other collector lists */
    GS->gray = nullptr;
    GS->grayagain = nullptr;
    GS->weak = nullptr;
    GS->gcstate = GCSsweepstring;
  }
  /* finish any pending sweep phase */
  while (GS->gcstate != GCSfinalize) {
    singlestep(L);
  }
  markroot(L);
  while (GS->gcstate != GCSpause) {
    singlestep(L);
  }
  setthreshold(GS);
}


void luaC_barrierf (lua_State *L, GCObject *o, GCObject *v) {
  /* must keep invariant? */
  if (GS->gcstate == GCSpropagate)
    reallymarkobject(GS, v);  /* restore invariant */
  else  /* don't mind */
    makewhite(GS, o);  /* mark as white just to avoid other barriers */
}


void luaC_barrierback (lua_State *L, Table *t) {
  GCObject *o = (t);
  black2gray(o);  /* make table gray (again) */
  t->gclist = GS->grayagain;
  GS->grayagain = o;
}


void luaC_link (lua_State *L, GCObject *o, byte tt) {
  o->next = GS->rootgc;
  GS->rootgc = o;
  o->marked = luaC_white(GS);
  o->tt = tt;
}


void luaC_linkupval (lua_State *L, UpVal *uv) {
  GCObject *o = (uv);
  o->next = GS->rootgc;  /* link upvalue into `rootgc' list */
  GS->rootgc = o;
  if (isgray(o)) { 
    if (GS->gcstate == GCSpropagate) {
      gray2black(o);  /* closed upvalues need barrier */
      luaC_barrier(L, uv, uv->v);
    }
    else {  /* sweep phase: sweep it (turning it into white) */
      makewhite(GS, o);
    }
  }
}

