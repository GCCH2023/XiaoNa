// ͨ���������ӿ�
#include <string.h>
#include "lua.h"
#include "llimits.h"
#include "lmem.h"
#include "lstate.h"
#include "lzio.h"

CharStream::CharStream(){}

CharStream::CharStream(lua_State *L, lua_Reader reader, void *data)
{
	this->L = L;
	this->reader = reader;
	this->data = data;
	unread = 0;
	p = nullptr;
}

// ��ȡ��������ַ�������
int CharStream::fill()
{
	size_t size;
	const char *buff;
	
	buff = reader(L, data, &size);
	
	if (buff == nullptr || size == 0) return EOS;
	unread = size - 1;
	p = buff;
	return char2int(*(p++));
}

// ��ȡǰ���ַ�
int CharStream::peek() {
	if (unread == 0) {
		if (fill() == EOS) return EOS;
		unread++;  /* luaZ_fill removed first byte; put back it */
		p--;
	}
	return char2int(*p);
}



/* --------------------------------------------------------------- read --- */
// ��ȡ��������n���ַ�
size_t CharStream::read(void *b, size_t n)
{
	while (n) {
		size_t m;
		if (peek() == EOS) return n;  /* return number of missing bytes */
		m = (n <= unread) ? n : unread;  /* min. between n and z->unread */
		memcpy(b, p, m);
		unread -= m;
		p += m;
		b = (char *)b + m;
		n -= m;
	}
	return 0;
}

/* ------------------------------------------------------------------------ */
char *Mbuffer::openspace(lua_State *L, size_t n)
{
	if (n > buffsize) {
		if (n < LUA_MINBUFFER) n = LUA_MINBUFFER;
		resize(L, n);
	}
	return buffer;
}

Mbuffer::Mbuffer()
{
	buffer = nullptr;
	buffsize = 0;
}