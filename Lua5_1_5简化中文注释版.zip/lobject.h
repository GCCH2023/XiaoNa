#pragma once
// Lua�������Ͷ���
#include <stdarg.h>
#include "llimits.h"
#include "lua.h"

/* tags for values visible from Lua */
// Lua�����п��Ե�ֵ
#define LAST_TAG	LUA_TTHREAD
// �ɼ�ֵ����
#define NUM_TAGS	(LAST_TAG+1)

// ���ɼ�ֵ�ı�־
#define LUA_TPROTO	(LAST_TAG+1)
#define LUA_TUPVAL	(LAST_TAG+2)
#define LUA_TDEADKEY	(LAST_TAG+3)

// ���пɻ��ն���Ļ���
struct GCObject {
	GCObject *next;
	byte tt;
	byte marked;
};

// ���ڱ�ʾ����Luaֵ������
union Value{
	GCObject *gc;
	void *p;
	lua_Number n;
	int b;
} ;

// �����͵�ֵ
struct TValue {
	Value value;
	int tt;
};

// ���Ͳ��Ժ�
#define ttisnil(o)	(ttype(o) == LUA_TNIL)
#define ttisnumber(o)	(ttype(o) == LUA_TNUMBER)
#define ttisstring(o)	(ttype(o) == LUA_TSTRING)
#define ttistable(o)	(ttype(o) == LUA_TTABLE)
#define ttisfunction(o)	(ttype(o) == LUA_TFUNCTION)
#define ttisboolean(o)	(ttype(o) == LUA_TBOOLEAN)
#define ttisuserdata(o)	(ttype(o) == LUA_TUSERDATA)
#define ttisthread(o)	(ttype(o) == LUA_TTHREAD)
#define ttislightuserdata(o)	(ttype(o) == LUA_TLIGHTUSERDATA)

// ����ֵ�ĺ�
#define ttype(o)	((o)->tt)
#define gcvalue(o)	((o)->value.gc)
#define pvalue(o)	((o)->value.p)
#define nvalue(o)	((o)->value.n)
#define tsvalue(o)	((TString *)(o)->value.gc)
#define uvalue(o)	((Udata *)(o)->value.gc)
#define clvalue(o)	((Closure *)(o)->value.gc)
#define hvalue(o)	((Table *)(o)->value.gc)
#define bvalue(o)	((o)->value.b)
#define thvalue(o)	((lua_State *)(o)->value.gc)

// �Ƿ�false��ֻ�� ��nil�� �� ��false�� ��false
#define l_isfalse(o)	(ttisnil(o) || (ttisboolean(o) && bvalue(o) == 0))

// �������ڲ�����
#define checkliveness(g,obj) \
  ((ttype(obj) == (obj)->value.gc->tt) && !isdead(g, (obj)->value.gc))


// ����ֵ�ĺ�
#define setnilvalue(obj) ((obj)->tt=LUA_TNIL)

#define setnvalue(obj,x) \
  { TValue *i_o=(obj); i_o->value.n=(x); i_o->tt=LUA_TNUMBER; }

#define setpvalue(obj,x) \
  { TValue *i_o=(obj); i_o->value.p=(x); i_o->tt=LUA_TLIGHTUSERDATA; }

#define setbvalue(obj,x) \
  { TValue *i_o=(obj); i_o->value.b=(x); i_o->tt=LUA_TBOOLEAN; }

#define setsvalue(L,obj,x) \
  { TValue *i_o=(obj); \
    i_o->value.gc=cast(GCObject *, (x)); i_o->tt=LUA_TSTRING; \
    checkliveness(GS,i_o); }

#define setuvalue(L,obj,x) \
  { TValue *i_o=(obj); \
    i_o->value.gc=cast(GCObject *, (x)); i_o->tt=LUA_TUSERDATA; \
    checkliveness(GS,i_o); }

#define setthvalue(L,obj,x) \
  { TValue *i_o=(obj); \
    i_o->value.gc=cast(GCObject *, (x)); i_o->tt=LUA_TTHREAD; \
    checkliveness(GS,i_o); }

#define setclvalue(L,obj,x) \
  { TValue *i_o=(obj); \
    i_o->value.gc=cast(GCObject *, (x)); i_o->tt=LUA_TFUNCTION; \
    checkliveness(GS,i_o); }

#define sethvalue(L,obj,x) \
  { TValue *i_o=(obj); \
    i_o->value.gc=cast(GCObject *, (x)); i_o->tt=LUA_TTABLE; \
    checkliveness(GS,i_o); }

#define setptvalue(L,obj,x) \
  { TValue *i_o=(obj); \
    i_o->value.gc=cast(GCObject *, (x)); i_o->tt=LUA_TPROTO; \
    checkliveness(GS,i_o); }

#define setobj(L,obj1,obj2) \
  { const TValue *o2=(obj2); TValue *o1=(obj1); \
    o1->value = o2->value; o1->tt=o2->tt; \
    checkliveness(GS,o1); }


// ��������
#define setttype(obj, tt) (ttype(obj) = (tt))
// ֵ�Ƿ���Ի���
#define iscollectable(o)	(ttype(o) >= LUA_TSTRING)
// ָ��ջ�е�Ԫ��
typedef TValue *StkId;  /* index to stack elements */

#define getstr(ts)	cast(const char *, (ts) + 1)
#define svalue(o)       getstr(tsvalue(o))

struct TString;

/* masks for new-style vararg */
#define VARARG_HASARG		1
#define VARARG_ISVARARG		2
#define VARARG_NEEDSARG		4


struct LocVar {
  TString *varname;
  int startpc;  /* first point where variable is active */
  int endpc;    /* first point where variable is dead */
};

/*
** Upvalues
*/
struct UpVal : GCObject{
	TValue *v;  /* points to stack or to its own value */
	union {
		TValue value;  /* the value (when closed) */
		struct {  /* double linked list (when open) */
			struct UpVal *prev;
			struct UpVal *next;
		} l;
	} u;
	static UpVal* New(lua_State *L);
	static void Del(lua_State *L, UpVal *uv);
};

/*
** `module' operation for hashing (size is always a power of 2)
*/
#define lmod(s,size) \
	(((cast(int, (s) & ((size)-1)))))

#define twoto(x)	(1<<(x))
#define sizenode(t)	(twoto((t)->lsizenode))

#define luaO_nilobject		(&luaO_nilobject_)
LUAI_DATA const TValue luaO_nilobject_;

#define ceillog2(x)	(luaO_log2((x)-1) + 1)

int luaO_log2 (unsigned int x);
int luaO_int2fb (unsigned int x);
int luaO_fb2int (int x);
int luaO_rawequalObj (const TValue *t1, const TValue *t2);
int luaO_str2d (const char *s, lua_Number *result);
//const char *luaO_pushvfstring (lua_State *L, const char *fmt,
//                                                       va_list argp);
//const char *luaO_pushfstring (lua_State *L, const char *fmt, ...);
void luaO_chunkid (char *out, const char *source, size_t len);