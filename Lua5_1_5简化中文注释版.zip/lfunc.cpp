// ��������������������ͷ�ͱհ�
#include <stddef.h>

#define lfunc_c
#define LUA_CORE
#include "lua.h"
#include "lfunc.h"
#include "lgc.h"
#include "lmem.h"
#include "lobject.h"
#include "lstate.h"


CClosure *CClosure::New(lua_State *L, int nelems, Table *e) {
	CClosure *c = cast(CClosure *, luaM_malloc(L, sizeCclosure(nelems)));
	luaC_link(L, c, LUA_TFUNCTION);
	c->isC = true;
	c->env = e;
	c->nupvalues = cast_byte(nelems);
	return c;
}


LClosure *LClosure::New(lua_State *L, int nelems, Table *e) {
	LClosure *c = cast(LClosure *, luaM_malloc(L, sizeLclosure(nelems)));
	luaC_link(L, c, LUA_TFUNCTION);
	c->isC = false;
	c->env = e;
	c->nupvalues = cast_byte(nelems);
	while (nelems--) c->upvals[nelems] = nullptr;
	return c;
}


UpVal *UpVal::New(lua_State *L) {
	UpVal *uv = luaM_new(L, UpVal);
	luaC_link(L, uv, LUA_TUPVAL);
	uv->v = &uv->u.value;
	setnilvalue(uv->v);
	return uv;
}


UpVal *luaF_findupval(lua_State *L, StkId level) {
	GCObject **pp = &L->openupval;
	UpVal *p;
	UpVal *uv;
	// ���ϲ�������в���
	while (*pp != nullptr && (p = gco2uv(*pp))->v >= level) {
		if (p->v == level) {  // �ҵ�����Ӧ���ϲ���� /* found a corresponding upvalue? */
			if (isdead(GS, (p)))  // ������� /* is it dead? */
				changewhite((p));  // ������ /* ressurect it */
			return p;
		}
		pp = &p->next;
	}
	// �Ҳ����ʹ���
	uv = luaM_new(L, UpVal);  /* not found: create a new one */
	uv->tt = LUA_TUPVAL;
	uv->marked = luaC_white(GS);
	uv->v = level;  // ��ǰֵ��ջ�� /* current value lives in the stack */
	uv->next = *pp;  // �����ʵ�λ�� /* chain it in the proper position */
	*pp = (uv);
	uv->u.l.prev = &GS->uvhead;  /* double link it in `uvhead' list */
	uv->u.l.next = GS->uvhead.u.l.next;
	uv->u.l.next->u.l.prev = uv;
	GS->uvhead.u.l.next = uv;
	return uv;
}


static void unlinkupval(UpVal *uv) {
	// ��˫�������Ƴ�
	uv->u.l.next->u.l.prev = uv->u.l.prev;  /* remove from `uvhead' list */
	uv->u.l.prev->u.l.next = uv->u.l.next;
}


void UpVal::Del(lua_State *L, UpVal *uv) {
	if (uv->v != &uv->u.value)  /* is it open? */
		unlinkupval(uv);  /* remove from open list */
	luaM_free(L, uv);  /* free upvalue */
}


void luaF_close(lua_State *L, StkId level) {
	UpVal *uv;
	while (L->openupval != nullptr && (uv = gco2uv(L->openupval))->v >= level) {
		GCObject *o = (uv);
		L->openupval = uv->next;  /* remove from `open' list */
		if (isdead(GS, o))
			UpVal::Del(L, uv);  /* free upvalue */
		else {
			unlinkupval(uv);
			setobj(L, &uv->u.value, uv->v);
			uv->v = &uv->u.value;  /* now current value lives here */
			luaC_linkupval(L, uv);  /* link upvalue into `gcroot' list */
		}
	}
}


Proto *Proto::New(lua_State *L) {
	Proto *f = luaM_new(L, Proto);
	luaC_link(L, f, LUA_TPROTO);
	f->k = nullptr;
	f->sizek = 0;
	f->p = nullptr;
	f->sizep = 0;
	f->code = nullptr;
	f->sizecode = 0;
	f->sizelineinfo = 0;
	f->sizeupvalues = 0;
	f->nups = 0;
	f->upvalues = nullptr;
	f->numparams = 0;
	f->is_vararg = 0;
	f->maxstacksize = 0;
	f->lineinfo = nullptr;
	f->sizelocvars = 0;
	f->locvars = nullptr;
	f->linedefined = 0;
	f->lastlinedefined = 0;
	f->source = nullptr;
	return f;
}


void Proto::Del(lua_State *L, Proto *f) {
	luaM_freearray(L, f->code, f->sizecode, Instruction);
	luaM_freearray(L, f->p, f->sizep, Proto *);
	luaM_freearray(L, f->k, f->sizek, TValue);
	luaM_freearray(L, f->lineinfo, f->sizelineinfo, int);
	luaM_freearray(L, f->locvars, f->sizelocvars, struct LocVar);
	luaM_freearray(L, f->upvalues, f->sizeupvalues, TString *);
	luaM_free(L, f);
}


void Closure::Del(lua_State *L, Closure *c) {
	int size = (c->isC) ? sizeCclosure(ccl(c)->nupvalues) :
		sizeLclosure(lcl(c)->nupvalues);
	luaM_freemem(L, c, size);
}


/*
** Look for n-th local variable at line `line' in function `func'.
** Returns nullptr if not found.
*/
// ���ҵ�n���������Ҳ������ؿ�ֵ
const char *Proto::getlocalname(int local_number, int pc) {
	for (int i = 0; i < sizelocvars && locvars[i].startpc <= pc; i++) {
		if (pc < locvars[i].endpc) {  // ������Ծ�� /* is variable active? */
			local_number--;
			if (local_number == 0)
				return getstr(locvars[i].varname);
		}
	}
	return nullptr;  /* not found */
}