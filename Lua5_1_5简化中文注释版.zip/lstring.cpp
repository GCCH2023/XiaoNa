/*
** $Id: lstring.c,v 2.8.1.1 2007/12/27 13:02:25 roberto Exp $
** String table (keeps all strings handled by Lua)
** See Copyright Notice in lua.h
*/


#include <string.h>

#define lstring_c
#define LUA_CORE

#include "lua.h"

#include "lmem.h"
#include "lobject.h"
#include "lstate.h"
#include "lstring.h"


// ɢ�к���
inline int hashmod(size_t n, size_t size)
{
	return (int)(n & (size - 1));
}

// �������й�ϣֵ���ַ���ȡ�µĹ�ϣֵ
inline size_t newhash(size_t oldhash, char c)
{
	return oldhash ^ ((oldhash << 5) + (oldhash >> 2) + (unsigned char)c);
}

// ��ȡ�ַ����Ĺ�ϣֵ
size_t gethash(const char *str, size_t len)
{
	// ����������ַ���̫��������ַ������ϣֵ
	size_t step = (len >> 5) + 1;
	// �����ϣֵ
	size_t hash = len;
	for (auto i = len; i >= step; i -= step)
		hash = newhash(hash, str[i - 1]);
	return hash;
}

void luaS_resize(lua_State *L, int newsize) {
	GCObject **newhash;
	stringtable *tb;
	int i;
	if (GS->gcstate == GCSsweepstring)
		return;  /* cannot resize during GC traverse */
	newhash = luaM_newvector(L, newsize, GCObject *);
	tb = &GS->strt;
	for (i = 0; i < newsize; i++) newhash[i] = nullptr;
	/* rehash */
	for (i = 0; i < tb->size; i++) {
		GCObject *p = tb->hash[i];
		while (p) {  /* for each node in the list */
			GCObject *next = p->next;  /* save next */
			unsigned int h = gco2ts(p)->hash;
			int h1 = lmod(h, newsize);  /* new position */
			p->next = newhash[h1];  /* chain it */
			newhash[h1] = p;
			p = next;
		}
	}
	luaM_freearray(L, tb->hash, tb->size, TString *);
	tb->size = newsize;
	tb->hash = newhash;
}


static TString *newlstr(lua_State *L, const char *str, size_t len,
	unsigned int hash) {
	TString *ts;
	stringtable *tb;
	// ��ⳤ��
	if (len + 1 > (MAX_SIZET - sizeof(TString)) / sizeof(char))
		luaM_toobig(L);
	// �����ڴ棬��������
	ts = cast(TString *, luaM_malloc(L, (len + 1)*sizeof(char)+sizeof(TString)));
	ts->len = len;
	ts->hash = hash;
	ts->marked = luaC_white(GS);
	ts->tt = LUA_TSTRING;
	ts->reserved = false;
	memcpy(ts + 1, str, len*sizeof(char));
	((char *)(ts + 1))[len] = '\0';  /* ending 0 */
	// �����ַ�������
	tb = &GS->strt;
	hash = lmod(hash, tb->size);
	ts->next = tb->hash[hash];  /* chain new entry */
	tb->hash[hash] = (ts);
	tb->nuse++;
	// �ַ�����̫ӵ������������
	if (tb->nuse > cast(lu_int32, tb->size) && tb->size <= MAX_INT / 2)
		luaS_resize(L, tb->size * 2);  /* too crowded */
	return ts;
}

// �����ַ���
TString *TString::New(lua_State *L, const char *str)
{
	return newstr(L, str, strlen(str));
}

TString *TString::newstr(lua_State *L, const char *str, size_t l) {
	GCObject *o;
	unsigned int hash = gethash(str, l);
	// �����ַ���
	for (o = GS->strt.hash[lmod(hash, GS->strt.size)];
		o != nullptr;
		o = o->next) {
		TString *ts = gco2ts(o);
		if (ts->len == l && (memcmp(str, getstr(ts), l) == 0)) {
			/* string may be dead */
			if (isdead(GS, o)) changewhite(o);
			return ts;
		}
	}
	return newlstr(L, str, l, hash);  /* not found */
}


Udata *Udata::New(lua_State *L, size_t s, Table *e) {
	// ��ⳤ��
	if (s > MAX_SIZET - sizeof(Udata))
		luaM_toobig(L);
	// �����ڴ��ʼ��
	Udata *u = cast(Udata *, luaM_malloc(L, s + sizeof(Udata)));
	u->marked = luaC_white(GS);  /* is not finalized */
	u->tt = LUA_TUSERDATA;
	u->len = s;
	u->metatable = nullptr;
	u->env = e;
	/* chain it on udata list (after main thread) */
	// �����û��������ϣ������߳�֮��
	u->next = GS->mainthread->next;
	GS->mainthread->next = (u);
	return u;
}