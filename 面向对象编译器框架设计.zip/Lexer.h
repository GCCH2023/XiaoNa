#pragma once
#include "ParserTemplate.h"
#include "Token.h"

class Lexer :
	public ParserTemplate<std::istream, TokenFactory, Token>
{
public:
	Lexer(std::istream& stream);
	virtual ~Lexer();
	virtual void lackerror() override;
};