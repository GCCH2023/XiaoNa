#include "ASTNode.h"


ASTNode::ASTNode()
{
}


ASTNode::~ASTNode()
{
}
