#pragma once
#include "Lexer.h"
#include "ASTNode.h"
#include "ParserTemplate.h"
#include <memory>

// ���ܽڵ�ָ��
using upNode = std::unique_ptr<ASTNode>;
// �����﷨���ڵ㹤��
using NodeFactory = FactoryTemplate<Lexer, upNode>;

class Parser :
	public ParserTemplate<Lexer, NodeFactory, ASTNode>
{
public:
	Parser(Lexer& lexer);
	virtual ~Parser();
	virtual void lackerror() override;
};

